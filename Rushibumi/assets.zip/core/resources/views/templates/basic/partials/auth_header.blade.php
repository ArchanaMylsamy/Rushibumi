<div class="account-section__header">
    <div class="container">
        <a href="{{ route('home') }}" class="account-section__logo">
            <img class="light-logo" src="{{ siteLogo() }}" alt="logo">
            <img class="dark-logo" src="{{ siteLogo('dark') }}" alt="logo">
        </a>
    </div>
</div>
