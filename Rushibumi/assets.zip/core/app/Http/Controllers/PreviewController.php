<?php

namespace App\Http\Controllers;

use App\Traits\ChannelManager;

class PreviewController extends Controller {
    use ChannelManager;
}
