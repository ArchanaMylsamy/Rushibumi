<?php

return [
    'home'=>false,
    'video.play'=>false,
    'preview.monthly.plan'=>false,
    'preview.playlist.videos'=>false,
];
